This mod Enables Amplified World Generation.

Folder(s): 'loc', 'resourcepacks', and 'templates'.
Is the mod itself.

While Folder(s): '_screenshotsJPG', '_screenshotsBMP', and '_tools'.
Are the tools from Development, and screenshots for the Unistore.